import tkinter as tk
import random

class DiceApp:
    def __init__(self, master):
        self.master = master
        self.master.title("🎲 Dice Roller")
        self.master.geometry("400x400")
        self.master.config(bg="#f0f8ff")

        self.label_title = tk.Label(master, text="🎲 Dice Roller", font=("Arial", 22, "bold"), bg="#f0f8ff", fg="#333")
        self.label_title.pack(pady=20)

        self.dice_label = tk.Label(master, text="🎯 Roll the Dice!", font=("Arial", 18), bg="#f0f8ff")
        self.dice_label.pack(pady=30)

        self.result_label = tk.Label(master, text="", font=("Arial", 40, "bold"), bg="#f0f8ff", fg="#333")
        self.result_label.pack(pady=20)

        self.roll_button = tk.Button(master, text="Roll 🎲", command=self.roll_dice,
                                     font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=10)
        self.roll_button.pack(pady=20)

        self.quit_button = tk.Button(master, text="Exit ❌", command=master.quit,
                                     font=("Arial", 12), bg="#f44336", fg="white", width=8)
        self.quit_button.pack(pady=10)

    def roll_dice(self):
        dice_value = random.randint(1, 6)
        dice_faces = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"]
        self.result_label.config(text=dice_faces[dice_value - 1])
        self.dice_label.config(text=f"You rolled a {dice_value}!")

if __name__ == "__main__":
    root = tk.Tk()
    app = DiceApp(root)
    root.mainloop()
